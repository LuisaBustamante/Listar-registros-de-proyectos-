<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="apple-touch-icon" sizes="76x76" href="view/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="view/assets/img/favicon.png">

    <title>Sistema de gestión de becas Icetex</title>

    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="view/assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="view/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

    <!-- CSS Files -->
    <link id="pagestyle" href="view/assets/css/material-dashboard.css?v=3.0.4" rel="stylesheet" />

</head>

<body class="g-sidenav-show  bg-gray-100">

    <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">

        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-4" href=" ">
                <img src="https://web.icetex.gov.co/image/layout_set_logo?img_id=241102&t=1665435595514" class="navbar-brand-img h-100" alt="main_logo">
            </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/dato_usuario/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">account_circle</i>
                        </div>
                        <span class="nav-link-text ms-1">Dato usuario</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/perfil_candidato/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">assignment_ind</i>
                        </div>

                        <span class="nav-link-text ms-1">Perfil candidato</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/estudio_academico/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">receipt_long</i>
                        </div>
                        <span class="nav-link-text ms-1">Estudio academico</span>
                    </a>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/exp_profesional/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">view_in_ar</i>
                        </div>
                        <span class="nav-link-text ms-1">Experiencia profesional</span>
                    </a>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/programa_ofertado/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">info_outline</i>
                        </div>
                        <span class="nav-link-text ms-1">Programa ofertado</span>
                    </a>
                </li>


                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/planificacion/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">insert_invitation </i>
                        </div>
                        <span class="nav-link-text ms-1">Planificacion becas</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/universidad/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">location_city</i>
                        </div>
                        <span class="nav-link-text ms-1">Universidades</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/programa_titulacion">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">storage</i>
                        </div>

                        <span class="nav-link-text ms-1">Programa titulacion</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/especialidad">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">turned_in_not</i>
                        </div>

                        <span class="nav-link-text ms-1">Especialidad</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-white " href="http://localhost/becas_icetex/model/solicitud_aceptada/">

                        <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="material-icons opacity-10">notifications</i>
                        </div>

                        <span class="nav-link-text ms-1">Solicitudes aceptadas</span>
                    </a>
                </li>

            </ul>
        </div>

    </aside>

    <main class="main-content border-radius-lg ">
        <div class="container-fluid py-3">
            <div class="row">
                <div class="col-lg-20 position-relative z-index-1">
                    <div class="card card-plain mb-4">
                        <div class="card-body p-3">
                            <div class="row">
                                <div class="col-lg-20">
                                    <div class="d-flex flex-column h-100">
                                        <h2 class="font-weight-bolder mb-2">Sistema de gestión academica ICETEX</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row row-cols-3 row-cols-md-3 g-4">
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Dato usuario</h5>
                                    <img src="https://pixabay.com/get/gf907cfa50c543b076fd9d71dc0b8cfab58ebb2b28d1c0252f8410ea6ed61f9338637ed3cdaa9d5bb2fe6fbec8ee256c3_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/dato_usuario/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Perfil Candidato</h5>
                                    <img src="https://pixabay.com/get/g6a3e673fd21636ca2b23f17e755b2b1dab29e242d021ee65d72c35740e4cf81a4cf7f9cbd981624c0fdad1d2cf4482f3_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/perfil_candidato/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Estudio academico</h5>
                                    <img src="https://pixabay.com/get/g3bc941c37f1085dfb92f41aff5b3a978ec5a0d269af5a251e30d8652e85a1119fe4156e764eaab577d8961e1687ae35e_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/estudio_academico/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Experiencia profesional</h5>
                                    <img src="https://pixabay.com/get/g3cba38853ebcface2fd4febf1f2a80ea22afda26d049b4e9bed4bd131d71aa4ebadd45eb66341d55583823bff111ed0117daeba05fbf6b032d792049f16938985b9d7db84c117ce60be2478e568fc1ff_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/exp_profesional/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Programa ofertado</h5>
                                    <img src="https://pixabay.com/get/gcd81679b61c80044f439f8f969310e446350c43fab7b61d7f86179508accdc08f52c6eabf1cb823b74d6c2335d2c182c34aeb212a2756e35ce45969e1d9d91ff09d27f0144b5b6167e58a38dba316d68_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/programa_ofertado/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Planificación</h5>
                                    <img src="https://pixabay.com/get/gfd574a8cfa554ccd10c7d2711eaf8845782b293941dd555b3feb4a4d2c28fbd0e1bd71c1218af7da28a371f4a933d86b1b38e84f5442adfa81fc93521064c3c0c97bc2b64c860b33638c59df1078c659_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/planificacion/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Universidades</h5>
                                    <img src="https://pixabay.com/get/gf71f727f04b98dc362600c5cffea5c34362d79e36f758c9e22e1c41374dc2289a724d725e27de224e997fd6bafb1959c7a28e4d619aff343f3be795ace4bdc3a7b4c63eee8a63a0b81c4ea4b258ea9cd_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/universidad/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Programa de titulacion</h5>
                                    <img src="https://pixabay.com/get/gf5184730479179ff7ae1516294f43213496c2fb5d7b68a2db10637117bb294c5a1715882463d622d53b6954903e31e447a50650dbf9a343f41b3d91940867dc929e3a844e07e17c5975867be2690054f_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/programa_titulacion/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Especialidad</h5>
                                    <img src="https://pixabay.com/get/g6fc9108dd0f6d88ef97cce3f8bda1cd96c39700f1cc33189cd437b66fc00545598669616d6d08891a763917e16c65f2881149ecf2d1f3560c40ad25880f94aa9117a3e267d38789d642bca89035ff44f_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/especialidad/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">Solicitud aceptada</h5>
                                    <img src="https://pixabay.com/get/gb54a60f8cd52ac24a0ccce90e37a368630c5654c2c9387e0446cc0410787cf12970c9573b2efc75e1a20af8dea9fc6cdf8ab57878de73d01561f3e2e7a19db2585d74187507d63d552343e753d5d1a26_640.png" class="card-img-top" alt="...">
                                </div>
                                <div class="card-footer">
                                    <button class="btn btn-warning" type="button"><a href="http://localhost/becas_icetex/model/solicitud_aceptada/" target="_blank"> Ver más</a></button>
                                </div>
                            </div>
                        </div>

                    </div>

                    <footer class="footer py-4  ">
                        <div class="container-fluid">
                            <div class="row align-items-center justify-content-lg-between">
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="copyright text-center text-sm text-muted text-lg-start">
                                        ©
                                        <script>
                                            document.write(new Date().getFullYear())
                                        </script>,
                                        made with
                                        <i class="fa fa-heart"></i>
                                        by
                                        <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">ICETEX</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>

                </div>


    </main>


    <!--   Core JS Files   -->
    <script src="view/assets/js/core/popper.min.js"></script>
    <script src="view/assets/js/core/bootstrap.min.js"></script>
    <script src="view/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="view/assets/js/plugins/smooth-scrollbar.min.js"></script>


    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>

    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>


    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="view/assets/js/material-dashboard.min.js?v=3.0.4"></script>
</body>

</html>
</body>

</html>