<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$fecha_aceptacion_solicitud = $fecha_inicio_sa = $fecha_final_sa = $observacion_sa = $estado_beca = "";
$fecha_aceptacion_solicitud_err = $fecha_inicio_sa_err = $fecha_final_sa_err = $observacion_sa_err = $estado_beca_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion fecha aceptacion soliciutd
    $input_fecha_aceptacion = trim($_POST["fecha_aceptacion_solicitud"]);
    if (empty($input_fecha_aceptacion)) {
        $fecha_aceptacion_solicitud_err = "Por favor ingresa una fecha";
    } else {
        $fecha_aceptacion_solicitud = $input_fecha_aceptacion;
    }

    // Validacion fecha inicio solicitud 
    $input_fecha_inicio = trim($_POST["fecha_inicio_sa"]);
    if (empty($input_fecha_inicio)) {
        $fecha_inicio_sa_err = "Por favor ingresa una fecha";
    } else {
        $fecha_inicio_sa = $input_fecha_inicio;
    }
    // Validacion fecha final solicitud 
    $input_fecha_final = trim($_POST["fecha_final_sa"]);
    if (empty($input_fecha_final)) {
        $fecha_final_sa_err = "Por favor ingresa una fecha";
    } else {
        $fecha_final_sa = $input_fecha_final;
    }
    // Validacion observacion solicitud 
    $input_observacion = trim($_POST["observacion_sa"]);
    if (empty($input_observacion)) {
        $observacion_sa_err = "Por favor ingresa una observacion valida";
    } else {
        $observacion_sa = $input_observacion;
    }
    // Validacion estado beca
    $input_estado = trim($_POST["estado_beca"]);
    if (empty($input_estado)) {
        $estado_beca_err = "Por favor ingresa el estado de beca (Activo) o (Inactivo)";
    } else {
        $estado_beca = $input_estado;
    }

    // Revisamos errores antes de continuar
    if (empty($fecha_aceptacion_solicitud_err) && empty($fecha_inicio_sa_err) && empty($fecha_final_sa_err) && empty($observacion_sa_err) && empty($estado_beca_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO SOLICITUD_ACEPTADA (fecha_aceptacion_solicitud, fecha_inicio_sa, fecha_final_sa, observacion_sa, estado_beca ) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_fecha_aceptacion, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_fecha_inicio, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_final, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_observacion, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_estado, PDO::PARAM_STR);

            // settear variables
            $param_fecha_aceptacion = $fecha_aceptacion_solicitud;
            $param_fecha_inicio = $fecha_inicio_sa;
            $param_fecha_final = $fecha_final_sa;
            $param_observacion = $observacion_sa;
            $param_estado = $estado_beca;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar una solicitud de beca a la base de datos</p>

                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($fecha_aceptacion_solicitud_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de aceptacion de la solicitud</label>
                            <input type="date" name="fecha_aceptacion_solicitud" class="form-control" value="<?php echo $fecha_aceptacion_solicitud; ?>">
                            <span class="help-block"><?php echo $fecha_aceptacion_solicitud_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_inicio_sa_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de inicio de la solicitud</label>
                            <input type="date" name="fecha_inicio_sa" class="form-control" value="<?php echo $fecha_inicio_sa; ?>">
                            <span class="help-block"><?php echo $fecha_inicio_sa_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_final_sa_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha fin de la solicitud</label>
                            <input type="date" name="fecha_final_sa" class="form-control" value="<?php echo $fecha_final_sa; ?>">
                            <span class="help-block"><?php echo $fecha_final_sa_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($observacion_sa_err)) ? 'has-error' : ''; ?>">
                            <label>Observacion solicitud</label>
                            <textarea name="observacion_sa" class="form-control"><?php echo $observacion_sa; ?></textarea>
                            <span class="help-block"><?php echo $observacion_sa_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($estado_beca_err)) ? 'has-error' : ''; ?>">
                            <label>Estado de la beca</label>
                            <input type="text" name="estado_beca" class="form-control" value="<?php echo $estado_beca; ?>">
                            <span class="help-block"><?php echo $estado_beca_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>