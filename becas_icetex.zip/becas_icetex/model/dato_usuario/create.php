<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$usuario = $contraseña ="";
$usuario_err = $contraseña_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion usuario
    $input_usuario = trim($_POST["usuario"]);
    if (empty($input_usuario)) {
        $usuario_err = "Por favor ingresa un usuario valido.";
    } else {
        $usuario = $input_usuario;
    }

    // Validacion contraseña
    $input_contraseña = trim($_POST["contrasena"]);
    if (empty($input_contraseña)) {
        $contraseña_err = "Por favor ingresa una contraseña";
    } else {
        $contraseña = $input_contraseña;
    }

    /*Fecha de creacion
    $input_fecha_creacion= trim($POST["fecha_creacion_acceso"]);
    $contr*/

    // Revisamos errores antes de continuar
    if (empty($usuario_err) && empty($contraseña_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO DATO_USUARIO (usuario, contrasena) VALUES (?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_usuario, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_contraseña, PDO::PARAM_STR);


            // settear variables
            $param_usuario = $usuario;
            $param_contraseña = $contraseña;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar un dato de usuario a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($usuario_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre de usuario</label>
                            <input type="text" name="usuario" class="form-control" value="<?php echo $usuario; ?>">
                            <span class="help-block"><?php echo $usuario_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($contraseña_err)) ? 'has-error' : ''; ?>">
                            <label>Contraseña</label>
                            <input type="text" name="contrasena" class="form-control" value="<?php echo $contraseña; ?>">
                            <span class="help-block"><?php echo $contraseña_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>