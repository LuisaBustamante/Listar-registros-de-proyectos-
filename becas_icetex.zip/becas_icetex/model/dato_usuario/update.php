<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$usuario = $contraseña = $fecha_creacion_acceso = $fecha_ultima_modificacion = "";
$usuario_err = $contraseña_err = $fecha_creacion_err = $fecha_ultima_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_usuario"]) && !empty($_POST["id_usuario"])) {
    // Get hidden input value
    $id_usuario = $_POST["id_usuario"];

    // Validate nombre de usuario
    $input_usuario = trim($_POST["usuario"]);
    if (empty($input_usuario)) {
        $usuario_err = "Por favor ingresa un nombre de usuario.";
    }  else {
        $usuario = $input_usuario;
    }

    // Validate contraseña 
    $input_contraseña = trim($_POST["contrasena"]);
    if (empty($input_contraseña)) {
        $contraseña_err = "Ingresa una contraseña valida";
    } else {
        $contraseña = $input_contraseña;
    }


    // Check input errors before inserting in database
    if (empty($usuario_err) && empty($contraseña_err)) {
        // Prepare an update statement
        $sql = "UPDATE DATO_USUARIO SET usuario=?, contrasena=? WHERE id_usuario=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);

            $stmt->bindParam(1, $param_usuario, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_contraseña, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_id, PDO::PARAM_STR);



            // Set parameters
            $param_usuario = $usuario;
            $param_contraseña = $contraseña;
            $param_id = $id_usuario;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_usuario"]) && !empty(trim($_GET["id_usuario"]))) {
        // Get URL parameter
        $id_usuario =  trim($_GET["id_usuario"]);

        // Prepare a select statement
        $sql = "SELECT * FROM DATO_USUARIO WHERE id_usuario = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id_usuario;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $usuario = $row["USUARIO"];
                    $contraseña = $row["CONTRASENA"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($usuario_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre de usuario</label>
                            <input type="text" name="usuario" class="form-control" value="<?php echo $usuario; ?>">
                            <span class="help-block"><?php echo $usuario_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($contraseña_err)) ? 'has-error' : ''; ?>">
                            <label>Contraseña</label>
                            <input type="text" name="contrasena" class="form-control" value="<?php echo $contraseña; ?>">
                            <span class="help-block"><?php echo $contraseña_err; ?></span>
                        </div>
                    
                        <input type="hidden" name="id_usuario" value="<?php echo $id_usuario; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>