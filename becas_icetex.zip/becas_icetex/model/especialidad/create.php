<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$nombre_especialidad = $tipo_especialidad = "";
$nombre_especialidad_err = $tipo_especialidad_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion nombre especialidad
    $input_nombre = trim($_POST["nombre_especialidad"]);
    if (empty($input_nombre)) {
        $nombre_especialidad_err = "Por favor ingresa un nombre.";
    }  else {
        $nombre_especialidad = $input_nombre;
    }

    // Validacion tipo especialidad
    $input_tipo = trim($_POST["tipo_especialidad"]);
    if (empty($input_tipo)) {
        $tipo_especialidad_err = "Por favor ingresa un tipo de especialidad.";
    } else {
        $tipo_especialidad = $input_tipo;
    }



    // Revisamos errores antes de continuar
    if (empty($nombre_especialidad_err) && empty($tipo_especialidad_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO ESPECIALIDAD (nombre_especialidad, tipo_especialidad) VALUES (?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_nombre, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_tipo, PDO::PARAM_STR);

            // settear variables
            $param_nombre = $nombre_especialidad;
            $param_tipo = $tipo_especialidad;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar un empleado a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nombre_especialidad_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre especialidad</label>
                            <input type="text" name="nombre_especialidad" class="form-control" value="<?php echo $nombre_especialidad; ?>">
                            <span class="help-block"><?php echo $nombre_especialidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($tipo_especialidad_err)) ? 'has-error' : ''; ?>">
                            <label>Tipo especialidad</label>
                            <input type="text" name="tipo_especialidad" class="form-control" value="<?php echo $tipo_especialidad; ?>">
                            <span class="help-block"><?php echo $tipo_especialidad_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>