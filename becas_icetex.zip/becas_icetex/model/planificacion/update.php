<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$anio_p = $fecha_apertura_solicitud = $fecha_cierre_solicitud = $fecha_creacion_p = $fecha_aprobado_p = $num_univ_participantes = $estado_p = $pais_sede_programa = "";
$anio_p_err = $fecha_apertura_solicitud_err = $fecha_cierre_solicitud_err = $fecha_creacion_p_err = $fecha_aprobado_p_err = $num_univ_participantes_err = $estado_p_err = $pais_sede_programa_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_planificacion"]) && !empty($_POST["id_planificacion"])) {
    // Get hidden input value
    $id_planificacion = $_POST["id_planificacion"];


    // Validacion año 
    $input_anio = trim($_POST["anio_p"]);
    if (empty($input_anio)) {
        $anio_p_err = "Por favor ingresa un año.";
    } else {
        $anio_p = $input_anio;
    }

    // Validacion fecha_apertura_solicitud
    $input_fecha_apertura = trim($_POST["fecha_apertura_solicitud"]);
    if (empty($input_fecha_apertura)) {
        $fecha_apertura_solicitud_err = "Por favor ingresa una fecha";
    } else {
        $fecha_apertura_solicitud = $input_fecha_apertura;
    }

    // Validacion fecha cierre solicitud
    $input_fecha_cierre = trim($_POST["fecha_cierre_solicitud"]);
    if (empty($input_fecha_cierre)) {
        $fecha_cierre_solicitud_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_cierre_solicitud = $input_fecha_cierre;
    }

    // Validacion fecha creacion
    $input_fecha_creacion = trim($_POST["fecha_creacion_p"]);
    if (empty($input_fecha_creacion)) {
        $fecha_creacion_p_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_creacion_p = $input_fecha_creacion;
    }
    // Validacion fecha aprobado
    $input_fecha_aprobado = trim($_POST["fecha_aprobado_p"]);
    if (empty($input_fecha_aprobado)) {
        $fecha_aprobado_p_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_aprobado_p = $input_fecha_aprobado;
    }
    // Validacion  numero de universidades participantes
    $input_num_participantes = trim($_POST["num_univ_participantes"]);
    if (empty($input_num_participantes)) {
        $num_univ_participantes_err = "Por favor ingresa un numero valido.";
    } else {
        $num_univ_participantes = $input_num_participantes;
    }

    //Validacion estado planificacion
    $input_estado_p = trim($_POST["estado_p"]);
    if (empty($input_estado_p)) {
        $estado_p_err = "Por favor ingresa un estado valido.";
    } else {
        $estado_p = $input_estado_p;
    }

    // Validacion pais sede programa
    $input_pais_sede = trim($_POST["pais_sede_programa"]);
    if (empty($input_pais_sede)) {
        $pais_sede_programa_err = "Por favor ingresa un estado valido.";
    } else {
        $pais_sede_programa =  $input_pais_sede;
    }

    // Check input errors before inserting in database
    if (empty($anio_p_err) && empty($fecha_apertura_solicitud_err) && empty($fecha_cierre_solicitud_err) && empty($fecha_creacion_p_err) && empty($fecha_aprobado_p_err) && empty($num_univ_participantes_er) && empty($estado_p_err) && empty($pais_sede_programa_err)) {
        // Prepare an update statement
        $sql = "UPDATE PLANIFICACION SET anio_p=?, fecha_apertura_solicitud=?, fecha_cierre_solicitud=?, fecha_creacion_p=?, fecha_aprobado_p=?, num_univ_participantes=?, estado_p=?, pais_sede_progrma=? WHERE id_planificacion=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_anio_p, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_fecha_apertura, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_cierre, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_fecha_creacion, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_fecha_aprobado, PDO::PARAM_STR);
            $stmt->bindParam(6, $param_num_participantes, PDO::PARAM_STR);
            $stmt->bindParam(7, $param_estado_p, PDO::PARAM_STR);
            $stmt->bindParam(8, $param_pais_sede, PDO::PARAM_STR);
            $stmt->bindParam(9, $param_id, PDO::PARAM_INT);


            // Set parameters
            $param_anio_p = $anio_p;
            $param_fecha_apertura = $fecha_apertura_solicitud;
            $param_fecha_cierre = $fecha_cierre_solicitud;
            $param_fecha_creacion = $fecha_creacion_p;
            $param_fecha_aprobado = $fecha_aprobado_p;
            $param_num_participantes = $num_univ_participantes;
            $param_estado_p = $estado_p;
            $param_pais_sede = $pais_sede_programa;
            $param_id = $id_planificacion;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_planificacion"]) && !empty(trim($_GET["id_planificacion"]))) {
        // Get URL parameter
        $id_planificacion =  trim($_GET["id_planificacion"]);

        // Prepare a select statement
        $sql = "SELECT * FROM PLANIFICACION WHERE id_planificacion = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id_planificacion;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $anio_p = $row["ANIO_P"];
                    $fecha_apertura_solicitud = $row["FECHA_APERTURA_SOLICITUD"];
                    $fecha_cierre_solicitud = $row["FECHA_CIERRE_SOLICITUD"];
                    $fecha_creacion_p = $row["FECHA_CREACION_P"];
                    $fecha_aprobado_p = $row["FECHA_APROBADO_P"];
                    $num_univ_participantes = $row["NUM_UNIV_PARTICIPANTES"];
                    $estado_p = $row["ESTADO_P"];
                    $pais_sede_programa = $row["PAIS_SEDE_PROGRAMA"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($anio_p_err)) ? 'has-error' : ''; ?>">
                            <label>Año planificacion</label>
                            <input type="number" name="anio_p" class="form-control" value="<?php echo $anio_p; ?>">
                            <span class="help-block"><?php echo $anio_p_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_apertura_solicitud_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha apertura planificacion</label>
                            <input type="date" name="fecha_apertura_solicitud" class="form-control" value="<?php echo $fecha_apertura_solicitud; ?>">
                            <span class="help-block"><?php echo $fecha_apertura_solicitud_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_cierre_solicitud_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha cierre planificacion</label>
                            <input type="date" name="fecha_cierre_solicitud" class="form-control" value="<?php echo $fecha_cierre_solicitud; ?>">
                            <span class="help-block"><?php echo $fecha_cierre_solicitud_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_creacion_p_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha creacion planificacion</label>
                            <input type="date" name="fecha_creacion_p" class="form-control" value="<?php echo $fecha_creacion_p; ?>">
                            <span class="help-block"><?php echo $fecha_creacion_p_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_aprobado_p_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha aprobado planificacion</label>
                            <input type="date" name="fecha_aprobado_p" class="form-control" value="<?php echo $fecha_aprobado_p; ?>">
                            <span class="help-block"><?php echo $fecha_aprobado_p_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($num_univ_participantes_err)) ? 'has-error' : ''; ?>">
                            <label>Numero de universidades participantes</label>
                            <input type="number" name="num_univ_participantes" class="form-control" value="<?php echo $num_univ_participantes; ?>">
                            <span class="help-block"><?php echo $num_univ_participantes_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($estado_p_err)) ? 'has-error' : ''; ?>">
                            <label>Estado planificacion</label>
                            <input type="text" name="estado_p" class="form-control" value="<?php echo $estado_p; ?>">
                            <span class="help-block"><?php echo $estado_p_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pais_sede_programa_err)) ? 'has-error' : ''; ?>">
                            <label>Pais sede programa</label>
                            <input type="text" name="pais_sede_programa" class="form-control" value="<?php echo $pais_sede_programa; ?>">
                            <span class="help-block"><?php echo $pais_sede_programa_err; ?></span>
                        </div>
                        <input type="hidden" name="id_planificacion" value="<?php echo $id_planificacion; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>