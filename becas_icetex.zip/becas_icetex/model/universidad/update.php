<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$nombre_universidad = $pais_universidad = $ciudad_universidad = $direccion_universidad = $telefono_universidad = "";
$nombre_universidad_err = $pais_universidad_err = $ciudad_universidad_err = $direccion_universidad_err = $telefono_universidad_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_universidad"]) && !empty($_POST["id_universidad"])) {
    // Get hidden input value
    $id_universidad = $_POST["id_universidad"];

    // Validacion nombre universidad
    $input_nombre_universidad = trim($_POST["nombre_universidad"]);
    if (empty($input_nombre_universidad)) {
        $nombre_universidad_err = "Por favor ingresa un nombre de universidad valido.";
    } else {
        $nombre_universidad = $input_nombre_universidad;
    }

    // Validacion pais universidad
    $input_pais_universidad = trim($_POST["pais_universidad"]);
    if (empty($input_pais_universidad)) {
        $pais_universidad_err = "Por favor ingresa un pais valido.";
    } else {
        $pais_universidad = $input_pais_universidad;
    }

    // Validacion ciudad universidad

    $input_ciudad_universidad = trim($_POST["ciudad_universidad"]);
    if (empty($input_ciudad_universidad)) {
        $ciudad_universidad_err = "Por favor ingresa una ciudad valida.";
    } else {
        $ciudad_universidad = $input_ciudad_universidad;
    }

    // Validacion direccion universidad
    $input_direccion_universidad = trim($_POST["direccion_universidad"]);
    if (empty($input_direccion_universidad)) {
        $direccion_universidad_err = "Por favor ingresa una dirección valida.";
    } else {
        $direccion_universidad = $input_direccion_universidad;
    }

    // Validacion telefono universidad
    $input_telefono_universidad = trim($_POST["telefono_universidad"]);
    if (empty($input_telefono_universidad)) {
        $telefono_universidad_err = "Por favor ingresa un telefono valido.";
    } else {
        $telefono_universidad = $input_telefono_universidad;
    }


    // Check input errors before inserting in database
    if (empty($nombre_universidad_err) && empty($pais_universidad_err) && empty($ciudad_universidad_err) && empty($direccion_universidad_err) && empty($telefono_universidad_err)) {
        // Prepare an update statement
        $sql = "UPDATE UNIVERSIDAD SET nombre_universidad=?, pais_universidad=?, ciudad_universidad=?, direccion_universidad=?, telefono_universidad=? WHERE id_universidad=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_nombre_universidad, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_pais_universidad, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_ciudad_universidad, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_direccion_universidad, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_telefono_universidad, PDO::PARAM_STR);
            $stmt->bindParam(6, $param_id_universidad, PDO::PARAM_INT);

            // Set parameters
            $param_nombre_universidad = $nombre_universidad;
            $param_pais_universidad = $pais_universidad;
            $param_ciudad_universidad = $ciudad_universidad;
            $param_direccion_universidad = $direccion_universidad;
            $param_telefono_universidad = $telefono_universidad;
            $param_id_universidad = $id_universidad;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_universidad"]) && !empty(trim($_GET["id_universidad"]))) {
        // Get URL parameter
        $id_universidad =  trim($_GET["id_universidad"]);

        // Prepare a select statement
        $sql = "SELECT * FROM UNIVERSIDAD WHERE id_universidad = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id_universidad, PDO::PARAM_INT);

            // Set parameters
            $param_id_universidad = $id_universidad;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $nombre_universidad = $row["NOMBRE_UNIVERSIDAD"];
                    $pais_universidad = $row["PAIS_UNIVERSIDAD"];
                    $ciudad_universidad = $row["CIUDAD_UNIVERSIDAD"];
                    $direccion_universidad = $row["DIRECCION_UNIVERSIDAD"];
                    $telefono_universidad = $row["TELEFONO_UNIVERSIDAD"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nombre_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre universidad</label>
                            <input type="text" name="nombre_universidad" class="form-control" value="<?php echo $nombre_universidad; ?>">
                            <span class="help-block"><?php echo $nombre_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pais_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Pais universidad</label>
                            <input type="text" name="pais_universidad" class="form-control" value="<?php echo $pais_universidad; ?>">
                            <span class="help-block"><?php echo $pais_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($ciudad_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Ciudad universidad</label>
                            <input type="text" name="ciudad_universidad" class="form-control" value="<?php echo $ciudad_universidad; ?>">
                            <span class="help-block"><?php echo $ciudad_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($direccion_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Direccion</label>
                            <input type="text" name="direccion_universidad" class="form-control" value="<?php echo $direccion_universidad; ?>">
                            <span class="help-block"><?php echo $direccion_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($telefono_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Telefono</label>
                            <input type="text" name="telefono_universidad" class="form-control" value="<?php echo $telefono_universidad; ?>">
                            <span class="help-block"><?php echo $telefono_universidad_err; ?></span>
                        </div>
                        <input type="hidden" name="id_universidad" value="<?php echo $id_universidad; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>