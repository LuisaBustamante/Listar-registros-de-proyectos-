<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$nombre_universidad = $pais_universidad = $ciudad_universidad = $direccion_universidad = $telefono_universidad = "";
$nombre_universidad_err = $pais_universidad_err = $ciudad_universidad_err = $direccion_universidad_err = $telefono_universidad_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion nombre universidad
    $input_nombre_universidad = trim($_POST["nombre_universidad"]);
    if (empty($input_nombre_universidad)) {
        $nombre_universidad_err = "Por favor ingresa un nombre de universidad valido.";
    } else {
        $nombre_universidad = $input_nombre_universidad;
    }

    // Validacion pais universidad
    $input_pais_universidad = trim($_POST["pais_universidad"]);
    if (empty($input_pais_universidad)) {
        $pais_universidad_err = "Por favor ingresa un pais valido.";
    } else {
        $pais_universidad = $input_pais_universidad;
    }

    // Validacion ciudad universidad

    $input_ciudad_universidad = trim($_POST["ciudad_universidad"]);
    if (empty($input_ciudad_universidad)) {
        $ciudad_universidad_err = "Por favor ingresa una ciudad valida.";
    } else {
        $ciudad_universidad = $input_ciudad_universidad;
    }

    // Validacion direccion universidad
    $input_direccion_universidad = trim($_POST["direccion_universidad"]);
    if (empty($input_direccion_universidad)) {
        $direccion_universidad_err = "Por favor ingresa una dirección valida.";
    } else {
        $direccion_universidad = $input_direccion_universidad;
    }

    // Validacion telefono universidad
    $input_telefono_universidad = trim($_POST["telefono_universidad"]);
    if (empty($input_telefono_universidad)) {
        $telefono_universidad_err = "Por favor ingresa un telefono valido.";
    } else {
        $telefono_universidad = $input_telefono_universidad;
    }


    // Revisamos errores antes de continuar
    if (empty($nombre_universidad_err) && empty($pais_universidad_err) && empty($ciudad_universidad_err) && empty($direccion_universidad_err) && empty($telefono_universidad_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO UNIVERSIDAD (nombre_universidad, pais_universidad, ciudad_universidad, direccion_universidad, telefono_universidad) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_nombre_universidad, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_pais_universidad, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_ciudad_universidad, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_direccion_universidad, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_telefono_universidad, PDO::PARAM_STR);

            // settear variables
            $param_nombre_universidad = $nombre_universidad;
            $param_pais_universidad = $pais_universidad;
            $param_ciudad_universidad = $ciudad_universidad;
            $param_direccion_universidad = $direccion_universidad;
            $param_telefono_universidad = $telefono_universidad;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar una universidad a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nombre_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre universidad</label>
                            <input type="text" name="nombre_universidad" class="form-control" value="<?php echo $nombre_universidad; ?>">
                            <span class="help-block"><?php echo $nombre_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pais_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Pais de procedencia universidad</label>
                            <input type="text" name="pais_universidad" class="form-control" value="<?php echo $pais_universidad; ?>">
                            <span class="help-block"><?php echo $pais_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($ciudad_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Ciudad universidad</label>
                            <input type="text" name="ciudad_universidad" class="form-control" value="<?php echo $ciudad_universidad; ?>">
                            <span class="help-block"><?php echo $ciudad_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($direccion_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Direccion</label>
                            <input type="text" name="direccion_universidad" class="form-control" value="<?php echo $direccion_universidad; ?>">
                            <span class="help-block"><?php echo $direccion_universidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($telefono_universidad_err)) ? 'has-error' : ''; ?>">
                            <label>Telefono</label>
                            <input type="text" name="telefono_universidad" class="form-control" value="<?php echo $telefono_universidad; ?>">
                            <span class="help-block"><?php echo $telefono_universidad_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>