<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$titulo_programa = $cantidad_creditos = $num_diplomados = $duracion_titulacion = $resumen_interes = "";
$titulo_programa_err = $cantidad_creditos_err = $num_diplomados_err = $duracion_titulacion_err = $resumen_interes_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion titulo programa 
    $input_titulo_programa = trim($_POST["titulo_programa"]);
    if (empty($input_titulo_programa)) {
        $titulo_programa_err = "Por favor ingresa un nombre de titulo de programa valido.";
    } else {
        $titulo_programa = $input_titulo_programa;
    }

    // Validacion cantidad_creditos
    $input_cantidad_creditos = trim($_POST["cantidad_creditos"]);
    if (empty($input_cantidad_creditos)) {
        $cantidad_creditos_err = "Por favor ingresa una cantidad de creditos valida.";
    } else {
        $cantidad_creditos = $input_cantidad_creditos;
    }

    // Validacion numeros de diplomados

    $input_num_diplomados = trim($_POST["num_diplomados"]);
    if (empty($input_num_diplomados)) {
        $num_diplomados_err = "Por favor ingresa numero de diplomados";
    } else {
        $num_diplomados = $input_num_diplomados;
    }

    // Validacion duracion titulacion 
    $input_duracion_titulacion = trim($_POST["duracion_titulacion"]);
    if (empty($input_duracion_titulacion)) {
        $duracion_titulacion_err = "Por favor ingresa cantidad de duracion de la titulacion";
    } else {
        $duracion_titulacion = $input_duracion_titulacion;
    }

    // Validacion resumen interes
    $input_resumen_interes = trim($_POST["resumen_interes"]);
    if (empty($input_resumen_interes)) {
        $resumen_interes_err = "Por favor ingresa el por que quieres ingresar al programa";
    } else {
        $resumen_interes = $input_resumen_interes;
    }


    // Revisamos errores antes de continuar
    if (empty($titulo_programa_err) && empty($cantidad_creditos_err) && empty($num_diplomados_err) && empty($duracion_titulacion_err) && empty($resumen_interes_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO PROGRAMA_TITULACION (titulo_programa, cantidad_creditos, num_diplomados, duracion_titulacion, resumen_interes) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_titulo_programa, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_cantidad_creditos, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_num_diplomados, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_duracion_titulacion, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_resumen_interes, PDO::PARAM_STR);

            // settear variables
            $param_titulo_programa = $titulo_programa;
            $param_cantidad_creditos = $cantidad_creditos;
            $param_num_diplomados = $num_diplomados;
            $param_duracion_titulacion = $duracion_titulacion;
            $param_resumen_interes = $resumen_interes;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar un programa titulacion base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($titulo_programa_err)) ? 'has-error' : ''; ?>">
                            <label>Titulo del programa de titulacion</label>
                            <input type="text" name="titulo_programa" class="form-control" value="<?php echo $titulo_programa; ?>">
                            <span class="help-block"><?php echo $titulo_programa_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($cantidad_creditos_err)) ? 'has-error' : ''; ?>">
                            <label>Cantidad de creditos</label>
                            <input type="number" name="cantidad_creditos" class="form-control" value="<?php echo $cantidad_creditos; ?>">
                            <span class="help-block"><?php echo $cantidad_creditos_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($num_diplomados_err)) ? 'has-error' : ''; ?>">
                            <label>Numero de diplomados</label>
                            <input type="number" name="num_diplomados" class="form-control" value="<?php echo $num_diplomados; ?>">
                            <span class="help-block"><?php echo $num_diplomados_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($duracion_titulacion_err)) ? 'has-error' : ''; ?>">
                            <label>Duracion de la titulacion en años</label>
                            <input type="number" name="duracion_titulacion" class="form-control" value="<?php echo $duracion_titulacion; ?>">
                            <span class="help-block"><?php echo $duracion_titulacion_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($resumen_interes_err)) ? 'has-error' : ''; ?>">
                            <label>Resumen del interes del programa</label>
                            <textarea name="resumen_interes" class="form-control"><?php echo $resumen_interes; ?></textarea>
                            <span class="help-block"><?php echo $resumen_interes_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>