<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$titulo_programa = $cantidad_creditos = $num_diplomados = $duracion_titulacion = $resumen_interes = "";
$titulo_programa_err = $cantidad_creditos_err = $num_diplomados_err = $duracion_titulacion_err = $resumen_interes_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_programa_titulacion"]) && !empty($_POST["id_programa_titulacion"])) {
    // Get hidden input value
    $id_programa_titulacion = $_POST["id_programa_titulacion"];

    // Validacion titulo programa 
    $input_titulo_programa = trim($_POST["titulo_programa"]);
    if (empty($input_titulo_programa)) {
        $titulo_programa_err = "Por favor ingresa un nombre de titulo de programa valido.";
    } else {
        $titulo_programa = $input_titulo_programa;
    }

    // Validacion cantidad_creditos
    $input_cantidad_creditos = trim($_POST["cantidad_creditos"]);
    if (empty($input_cantidad_creditos)) {
        $cantidad_creditos_err = "Por favor ingresa una cantidad de creditos valida.";
    } else {
        $cantidad_creditos = $input_cantidad_creditos;
    }

    // Validacion numeros de diplomados

    $input_num_diplomados = trim($_POST["num_diplomados"]);
    if (empty($input_num_diplomados)) {
        $num_diplomados_err = "Por favor ingresa numero de diplomados";
    } else {
        $num_diplomados = $input_num_diplomados;
    }

    // Validacion duracion titulacion 
    $input_duracion_titulacion = trim($_POST["duracion_titulacion"]);
    if (empty($input_duracion_titulacion)) {
        $duracion_titulacion_err = "Por favor ingresa cantidad de duracion de la titulacion";
    } else {
        $duracion_titulacion = $input_duracion_titulacion;
    }

    // Validacion resumen interes
    $input_resumen_interes = trim($_POST["resumen_interes"]);
    if (empty($input_resumen_interes)) {
        $resumen_interes_err = "Por favor ingresa el por que quieres ingresar al programa";
    } else {
        $resumen_interes = $input_resumen_interes;
    }

    // Check input errors before inserting in database
    if (empty($titulo_programa_err) && empty($cantidad_creditos_err) && empty($num_diplomados_err) && empty($duracion_titulacion_err) && empty($resumen_interes_err)) {
        // Prepare an update statement
        $sql = "UPDATE PROGRAMA_TITULACION SET titulo_programa=?, cantidad_creditos=?, num_diplomados=?, duracion_titulacion=?, resumen_interes=? WHERE id_programa_titulacion=?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_titulo_programa, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_cantidad_creditos, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_num_diplomados, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_duracion_titulacion, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_resumen_interes, PDO::PARAM_STR);
            $stmt->bindParam(6, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_titulo_programa = $titulo_programa;
            $param_cantidad_creditos = $cantidad_creditos;
            $param_num_diplomados = $num_diplomados;
            $param_duracion_titulacion = $duracion_titulacion;
            $param_resumen_interes = $resumen_interes;
            $param_id = $id_programa_titulacion;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_programa_titulacion"]) && !empty(trim($_GET["id_programa_titulacion"]))) {
        // Get URL parameter
        $id_programa_titulacion =  trim($_GET["id_programa_titulacion"]);

        // Prepare a select statement
        $sql = "SELECT * FROM PROGRAMA_TIULACION WHERE id_programa_titulacion = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id_programa_titulacion;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $titulo_programa = $row["TITULO_PROGRAMA"];
                    $cantidad_creditos= $row["CANTIDAD_CREDITOS"];
                    $num_diplomados = $row["NUM_DIPLOMADOS"];
                    $duracion_titulacion = $row["DURACION_TITULACION"];
                    $resumen_interes = $row["RESUMEN_INTERES"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                    <div class="form-group <?php echo (!empty($titulo_programa_err)) ? 'has-error' : ''; ?>">
                            <label>Titulo del programa de titulacion</label>
                            <input type="text" name="titulo_programa" class="form-control" value="<?php echo $titulo_programa; ?>">
                            <span class="help-block"><?php echo $titulo_programa_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($cantidad_creditos_err)) ? 'has-error' : ''; ?>">
                            <label>Cantidad de creditos</label>
                            <input type="number" name="cantidad_creditos" class="form-control" value="<?php echo $cantidad_creditos; ?>">
                            <span class="help-block"><?php echo $cantidad_creditos_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($num_diplomados_err)) ? 'has-error' : ''; ?>">
                            <label>Numero de diplomados</label>
                            <input type="text" name="num_diplomados" class="form-control" value="<?php echo $num_diplomados; ?>">
                            <span class="help-block"><?php echo $num_diplomados_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($duracion_titulacion_err)) ? 'has-error' : ''; ?>">
                            <label>Duracion de la titulacion</label>
                            <input type="text" name="duracion_titulacion" class="form-control" value="<?php echo $duracion_titulacion; ?>">
                            <span class="help-block"><?php echo $duracion_titulacion_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($resumen_interes_err)) ? 'has-error' : ''; ?>">
                            <label>Resumen del interes del programa</label>
                            <textarea name="resumen_interes" class="form-control"><?php echo $resumen_interes; ?></textarea>
                            <span class="help-block"><?php echo $resumen_interes_err; ?></span>
                        </div>
                        <input type="hidden" name="id_programa_titulacion" value="<?php echo $id_programa_titulacion; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>