<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Programa titulacion</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
        .wrapper {
            width: 650px;
            margin: 0 auto;
        }

        .page-header h2 {
            margin-top: 0;
        }

        table tr td:last-child a {
            margin-right: 15px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Detalles programa titulacion</h2>
                        <a href="create.php" class="btn btn-success pull-right">Agregar nuevo programa de titulacion</a>
                    </div>
                    <?php
                    // Include config file
                    require_once "config.php";

                    // Attempt select query execution
                    $sql = "SELECT * FROM PROGRAMA_TITULACION  ORDER BY ID_PROGRAMA_TITULACION ASC";
                    //if($result = mysqli_query($link, $sql)){
                    if ($result = $link->query($sql)) {
                        //if(mysqli_num_rows($result) > 0){
                        if ($result->fetchColumn() > 0) {
                            echo "<table class='table table-bordered table-striped'>";
                            echo "<thead>";
                            echo "<tr>";
                            echo "<th>ID programa titulacion</th>";
                            echo "<th>ID programa ofertado</th>";
                            echo "<th>ID especialidad</th>";
                            echo "<th>Titulo programa</th>";
                            echo "<th>Cantidad de creditos</th>";
                            echo "<th>Numero de diplomas</th>";
                            echo "<th>Duracion de titulacion</th>";
                            echo "<th>Resumen de interes</th>";
                            echo "<th>Acciones </th>";
                            echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";

                            //while($row = mysqli_fetch_array($result)){
                            foreach ($link->query($sql) as $row) {
                                echo "<tr>";
                                echo "<td>" . $row['ID_PROGRAMA_TITULACION'] . "</td>";
                                echo "<td>" . $row['ID_PROGRAMA_OFERTADO_PO'] . "</td>";
                                echo "<td>" . $row['ID_ESPECIALIDAD_TE'] . "</td>";
                                echo "<td>" . $row['TITULO_PROGRAMA'] . "</td>";
                                echo "<td>" . $row['CANTIDAD_CREDITOS'] . "</td>";
                                echo "<td>" . $row['NUM_DIPLOMADOS'] . "</td>";
                                echo "<td>" . $row['DURACION_TITULACION'] . "</td>";
                                echo "<td>" . $row['RESUMEN_INTERES'] . "</td>";
                                echo "<td>";
                                echo "<a href='read.php?id_programa_titulacion=" . $row['ID_PROGRAMA_TITULACION'] . "' title='Ver Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                echo "<a href='update.php?id_programa_titulacion=" . $row['ID_PROGRAMA_TITULACION'] . "' title='Actualizar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                echo "<a href='delete.php?id_programa_titulacion=" . $row['ID_PROGRAMA_TITULACION'] . "' title='Borrar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";
                            echo "</table>";
                            // Free result set
                            //mysqli_free_result($result);
                            $result->closeCursor(); //PDO close
                        } else {
                            echo "<p class='lead'><em>No hay registros que mostrar.</em></p>";
                        }
                    } else {
                        echo "ERROR: No se pudo ejecutar $sql. ";
                    }

                    // Close connection
                    //mysqli_close($link);
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>