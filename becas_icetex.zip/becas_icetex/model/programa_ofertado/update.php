<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$fecha_inicio_po = $fecha_final_po = $monto_aprobado_po = $financiamiento_extra_po = "";
$fecha_inicio_po_err = $fecha_final_po_err = $monto_aprobado_po_err = $financiamiento_extra_po_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_programa_ofertado"]) && !empty($_POST["id_programa_ofertado"])) {
    // Get hidden input value
    $id_programa_ofertado = $_POST["id_programa_ofertado"];

    // Validacion  fecha de inicio programa ofertado
    $input_fecha_inicio_po = trim($_POST["fecha_inicio_po"]);
    if (empty($input_fecha_inicio_po)) {
        $fecha_inicio_po_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_inicio_po = $input_fecha_inicio_po;
    }

    // Validacion  fecha final programa ofertado
    $input_fecha_final_po = trim($_POST["fecha_final_po"]);
    if (empty($input_fecha_final_po)) {
        $fecha_final_po_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_final_po = $input_fecha_final_po;
    }

    // Validacion monto aprobado

    $input_monto_aprobado = trim($_POST["monto_aprobado_po"]);
    if (empty($input_monto_aprobado)) {
        $monto_aprobado_po_err = "Por favor ingresa un monto valido.";
    } else {
        $monto_aprobado_po = $input_monto_aprobado;
    }

    // Validacion financiamiento_extra_po 
    $input_financiamiento = trim($_POST["financiamiento_extra_po"]);
    if (empty($input_financiamiento)) {
        $financiamiento_extra_po_err = "Por favor ingresa Si O N No.";
    } else {
        $financiamiento_extra_po = $input_financiamiento;
    }



    // Check input errors before inserting in database
    if (empty($fecha_inicio_po_err) && empty($fecha_final_po_err) && empty($monto_aprobado_po_err) && empty($financiamiento_extra_po_err)) {
        // Prepare an update statement
        $sql = "UPDATE PROGRAMA_OFERTADO SET fecha_incio_po=?, fecha_final_po=?, monto_aprobado_po=?, financiamiento_extra_po=?WHERE id_programa_ofertado=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_fecha_inicio_po, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_fecha_final_po, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_monto_aprobado_po, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_financiamiento_extra_po, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_fecha_inicio_po = $fecha_inicio_po;
            $param_fecha_final_po = $fecha_final_po;
            $param_monto_aprobado_po = $monto_aprobado_po;
            $param_financiamiento_extra_po = $financiamiento_extra_po;
            $param_id = $id_programa_ofertado;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_programa_ofertado"]) && !empty(trim($_GET["id_programa_ofertado"]))) {
        // Get URL parameter
        $id_programa_ofertado =  trim($_GET["id_programa_ofertado"]);

        // Prepare a select statement
        $sql = "SELECT * FROM PROGRAMA_OFERTADO WHERE id_programa_ofertado = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id= $id_programa_ofertado;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value

                    $fecha_inicio_po = $row["FECHA_INICIO_PO"];
                    $fecha_final_po = $row["FECHA_FINAL_PO"];
                    $monto_aprobado_po = $row["MONTO_APROBADO_PO"];
                    $financiamiento_extra_po = $row["FINANCIAMIENTO_EXTRA_PO"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                    <div class="form-group <?php echo (!empty($fecha_inicio_po_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha inicio programa ofertado</label>
                            <input type="date" name="fecha_inicio_po" class="form-control" value="<?php echo $fecha_inicio_po; ?>">
                            <span class="help-block"><?php echo $fecha_inicio_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_final_po_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha cierre programa ofertado</label>
                            <input type="date" name="fecha_final_po" class="form-control" value="<?php echo $fecha_final_po; ?>">
                            <span class="help-block"><?php echo $fecha_final_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($monto_aprobado_po_err)) ? 'has-error' : ''; ?>">
                            <label>Monto aprobado</label>
                            <input type="number" name="monto_aprobado_po" class="form-control" value="<?php echo $monto_aprobado_po; ?>">
                            <span class="help-block"><?php echo $monto_aprobado_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($financiamiento_extra_po_err)) ? 'has-error' : ''; ?>">
                            <label>Financiamiento extra</label>
                            <input type="text" name="financiamiento_extra_po" class="form-control" value="<?php echo $financiamiento_extra_po; ?>">
                            <span class="help-block"><?php echo $financiamiento_extra_po_err; ?></span>
                        </div>
                        <input type="hidden" name="id_programa_ofertado" value="<?php echo $id_programa_ofertado; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>