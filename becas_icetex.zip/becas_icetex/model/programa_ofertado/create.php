<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$fecha_inicio_po = $fecha_final_po = $monto_aprobado_po = $financiamiento_extra_po = "";
$fecha_inicio_po_err = $fecha_final_po_err = $monto_aprobado_po_err = $financiamiento_extra_po_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion  fecha de inicio programa ofertado
    $input_fecha_inicio_po = trim($_POST["fecha_inicio_po"]);
    if (empty($input_fecha_inicio_po)) {
        $fecha_inicio_po_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_inicio_po= $input_fecha_inicio_po;
    }

     // Validacion  fecha final programa ofertado
     $input_fecha_final_po = trim($_POST["fecha_final_po"]);
     if (empty($input_fecha_final_po)) {
         $fecha_final_po_err = "Por favor ingresa una fecha.";
     } else {
         $fecha_final_po= $input_fecha_final_po;
     }

    // Validacion monto aprobado

    $input_monto_aprobado = trim($_POST["monto_aprobado_po"]);
    if (empty($input_monto_aprobado)) {
        $monto_aprobado_po_err = "Por favor ingresa un monto valido.";
    } else {
        $monto_aprobado_po = $input_monto_aprobado;
    }

    // Validacion financiamiento_extra_po 
    $input_financiamiento = trim($_POST["financiamiento_extra_po"]);
    if (empty($input_financiamiento)) {
        $financiamiento_extra_po_err = "Por favor ingresa Y (SI) O N (No).";
    } else {
        $financiamiento_extra_po = $input_financiamiento;
    }


    // Revisamos errores antes de continuar
    if (empty($fecha_inicio_po_err) && empty($fecha_final_po_err) && empty($monto_aprobado_po_err) && empty($financiamiento_extra_po_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO PROGRAMA_OFERTADO (fecha_inicio_po, fecha_final_po, monto_aprobado_po, financiamiento_extra_po) VALUES (?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_fecha_inicio_po, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_fecha_final_po, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_monto_aprobado_po, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_financiamiento_extra_po, PDO::PARAM_STR);

            // settear variables
            $param_fecha_inicio_po = $fecha_inicio_po;
            $param_fecha_final_po = $fecha_final_po;
            $param_monto_aprobado_po= $monto_aprobado_po;
            $param_financiamiento_extra_po = $financiamiento_extra_po;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar un programa ofertado a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($fecha_inicio_po_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha inicio programa ofertado</label>
                            <input type="date" name="fecha_inicio_po" class="form-control" value="<?php echo $fecha_inicio_po; ?>">
                            <span class="help-block"><?php echo $fecha_inicio_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_final_po_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha cierre programa ofertado</label>
                            <input type="date" name="fecha_final_po" class="form-control" value="<?php echo $fecha_final_po; ?>">
                            <span class="help-block"><?php echo $fecha_final_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($monto_aprobado_po_err)) ? 'has-error' : ''; ?>">
                            <label>Monto aprobado</label>
                            <input type="number" name="monto_aprobado_po" class="form-control" value="<?php echo $monto_aprobado_po; ?>">
                            <span class="help-block"><?php echo $monto_aprobado_po_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($financiamiento_extra_po_err)) ? 'has-error' : ''; ?>">
                            <label>Financiamiento extra</label>
                            <input type="text" name="financiamiento_extra_po" class="form-control" value="<?php echo $financiamiento_extra_po; ?>">
                            <span class="help-block"><?php echo $financiamiento_extra_po_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>