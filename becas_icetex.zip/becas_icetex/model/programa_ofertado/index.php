<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Programa ofertado</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
        .wrapper {
            width: 650px;
            margin: 0 auto;
        }

        .page-header h2 {
            margin-top: 0;
        }

        table tr td:last-child a {
            margin-right: 15px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Detalles Programa ofertado</h2>
                        <a href="create.php" class="btn btn-success pull-right">Agregar nueva programa ofertado</a>
                    </div>
                    <?php
                    // Include config file
                    require_once "config.php";

                    // Attempt select query execution
                    $sql = "SELECT * FROM PROGRAMA_OFERTADO  ORDER BY ID_PROGRAMA_OFERTADO ASC";
                    //if($result = mysqli_query($link, $sql)){
                    if ($result = $link->query($sql)) {
                        //if(mysqli_num_rows($result) > 0){
                        if ($result->fetchColumn() > 0) {
                            echo "<table class='table table-bordered table-striped'>";
                            echo "<thead>";
                            echo "<tr>";
                            echo "<th>ID Programa ofertado</th>";
                            echo "<th>ID Planificacion</th>";
                            echo "<th>ID Usuario </th>";
                            echo "<th>ID Universidad</th>";
                            echo "<th>Fecha inicio programa</th>";
                            echo "<th>Fecha final programa</th>";
                            echo "<th>Monto aprobado</th>";
                            echo "<th>Financiamiento extra</th>";
                            echo "<th>Acciones </th>";
                            echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";
                            //while($row = mysqli_fetch_array($result)){
                            foreach ($link->query($sql) as $row) {
                                echo "<tr>";
                                echo "<td>" . $row['ID_PROGRAMA_OFERTADO'] . "</td>";
                                echo "<td>" . $row['ID_PLANIFICACION_P'] . "</td>";
                                echo "<td>" . $row['ID_USUARIO_DU'] . "</td>";
                                echo "<td>" . $row['ID_UNIVERSIDAD_U'] . "</td>";
                                echo "<td>" . $row['FECHA_INICIO_PO'] . "</td>";
                                echo "<td>" . $row['FECHA_FINAL_PO'] . "</td>";
                                echo "<td>" . $row['MONTO_APROBADO_PO'] . "</td>";
                                echo "<td>" . $row['FINANCIAMIENTO_EXTRA_PO'] . "</td>";
                                echo "<td>";
                                echo "<a href='read.php?id_programa_ofertado=" . $row['ID_PROGRAMA_OFERTADO'] . "' title='Ver Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                echo "<a href='update.php?id_programa_ofertado=" . $row['ID_PROGRAMA_OFERTADO'] . "' title='Actualizar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                echo "<a href='delete.php?id_programa_ofertado=" . $row['ID_PROGRAMA_OFERTADO'] . "' title='Borrar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";
                            echo "</table>";
                            // Free result set
                            //mysqli_free_result($result);
                            $result->closeCursor(); //PDO close
                        } else {
                            echo "<p class='lead'><em>No hay registros que mostrar.</em></p>";
                        }
                    } else {
                        echo "ERROR: No se pudo ejecutar $sql. ";
                    }

                    // Close connection
                    //mysqli_close($link);
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>