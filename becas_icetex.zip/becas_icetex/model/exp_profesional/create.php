<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$puesto_ep = $entidad_trabajada_ep = $fecha_inicial_ep = $fecha_final_ep = "";
$puesto_ep_err = $entidad_trabajada_err = $fecha_inicial_err = $fecha_final_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion puesto
    $input_puesto = trim($_POST["puesto_ep"]);
    if (empty($input_puesto)) {
        $puesto_ep_err = "Por favor ingresa un puesto valido";
    } else {
        $puesto_ep = $input_puesto;
    }
    // Validacion entidad trabajada
    $input_entidad = trim($_POST["entidad_trabajada_ep"]);
    if (empty($input_entidad)) {
        $entidad_trabajada_err = "Por favor ingresa una entidad valida";
    } else {
        $entidad_trabajada_ep = $input_entidad;
    }

    // Validacion fecha inicial 
    $input_fecha_inicial = trim($_POST["fecha_inicial_ep"]);
    if (empty($input_fecha_inicial)) {
        $fecha_inicial_err = "Por favor ingresa una fecha valida";
    } else {
        $fecha_inicial_ep = $input_fecha_inicial;
    }

    // Validacion fecha final
    $input_fecha_final = trim($_POST["fecha_final_ep"]);
    if (empty($input_fecha_final)) {
        $fecha_final_err = "Por favor ingresa una fecha valida";
    } else {
        $fecha_final_ep = $input_fecha_final;
    }

    // Revisamos errores antes de continuar
    if (empty($puesto_ep_err) && empty($entidad_trabajada_err) && empty($fecha_inicial_err) && empty($fecha_final_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO  EXPERIENCIA_PROF (puesto_ep, entidad_trabajada_ep, fecha_inicial_ep, fecha_final_ep) VALUES (?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables paa la sentencia
            $stmt->bindParam(1, $param_puesto, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_entidad, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_inicial, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_fecha_final, PDO::PARAM_STR);

            // settear variables
            $param_puesto = $puesto_ep;
            $param_entidad = $entidad_trabajada_ep;
            $param_fecha_inicial = $fecha_inicial_ep;
            $param_fecha_final = $fecha_final_ep;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar estudio academico a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($puesto_ep_err)) ? 'has-error' : ''; ?>">
                            <label>Puesto entidad trabajada</label>
                            <input type="text" name="puesto_ep" class="form-control" value="<?php echo $puesto_ep; ?>">
                            <span class="help-block"><?php echo $puesto_ep_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($entidad_trabajada_err)) ? 'has-error' : ''; ?>">
                            <label>Entidad trabajada</label>
                            <input type="text" name="entidad_trabajada_ep" class="form-control" value="<?php echo $entidad_trabajada_ep; ?>">
                            <span class="help-block"><?php echo $entidad_trabajada_err; ?></span>
                        </div>

                        <div class="form-group <?php echo (!empty($fecha_inicial_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha inicial</label>
                            <input type="date" name="fecha_inicial_ep" class="form-control" value="<?php echo $fecha_inicial_ep; ?>">
                            <span class="help-block"><?php echo $fecha_inicial_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_final_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha final</label>
                            <input type="date" name="fecha_final_ep" class="form-control" value="<?php echo $fecha_final_ep; ?>">
                            <span class="help-block"><?php echo $fecha_final_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>