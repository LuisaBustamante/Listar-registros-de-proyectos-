<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$puesto_ep = $entidad_trabajada_ep = $fecha_inicial_ep = $fecha_final_ep = "";
$puesto_ep_err = $entidad_trabajada_err = $fecha_inicial_err = $fecha_final_err = "";

// Processing form data when form is submitted
if (isset($_POST["id_experiencia_prof"]) && !empty($_POST["id_experiencia_prof"])) {
    // Get hidden input value
    $id_experiencia_prof = $_POST["id_experiencia_prof"];

    // Validate puesto entidad
    $input_puesto = trim($_POST["puesto_ep"]);
    if (empty($input_puesto)) {
        $puesto_ep_err = "Por favor ingresa un nombre de puesto valido.";
    }  else {
        $puesto_ep = $input_puesto;
    }

    // Validate entidad trabajada
    $input_entidad = trim($_POST["entidad_trabajada_ep"]);
    if (empty($input_entidad)) {
        $entidad_trabajada_err = "Por favor ingresa un nombre de entidad valido.";
    } else {
        $entidad_trabajada_ep = $input_entidad;
    }

    // Validate fecha inicio 
    $input_fecha_inicial = trim($_POST["fecha_inicial_ep"]);
    if (empty($input_fecha_inicial)) {
        $fecha_inicial_err = "Ingresa una fecha valida";
    } else {
        $fecha_inicial_ep = $input_fecha_inicial;
    }
    
    // Validate fecha final
    $input_fecha_final = trim($_POST["fecha_final_ep"]);
    if (empty($input_fecha_final)) {
        $fecha_final_err = "Ingresa una fecha valida";
    } else {
        $fecha_final_ep = $input_fecha_final;
    }

   

    // Check input errors before inserting in database
    if (empty($puesto_ep_err) && empty($entidad_trabajada_err) && empty($fecha_inicial_err) && empty($fecha_final_err)) {
        // Prepare an update statement
        $sql = "UPDATE EXPERIENCIA_PROF SET puesto_ep=?, entidad_trabajada_ep=?, fecha_inicial_ep=?, fecha_final_ep=? WHERE id_experiencia_prof=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_puesto, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_entidad, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_inicial, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_fecha_final, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_puesto = $puesto_ep;
            $param_entidad = $entidad_trabajada_ep;
            $param_fecha_inicial = $fecha_inicial_ep;
            $param_fecha_final = $fecha_final_ep;
            $param_id = $id_experiencia_prof;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_experiencia_prof"]) && !empty(trim($_GET["id_experiencia_prof"]))) {
        // Get URL parameter
        $id_experiencia_prof =  trim($_GET["id_experiencia_prof"]);

        // Prepare a select statement
        $sql = "SELECT * FROM EXPERIENCIA_PROF WHERE id_experiencia_prof = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id_experiencia_prof;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $puesto_ep = $row["PUESTO_EP"];
                    $entidad_trabajada_ep = $row["ENTIDAD_TRABAJADA_EP"];
                    $fecha_inicial_ep = $row["FECHA_INICIAL_EP"];
                    $fecha_final_ep = $row["FECHA_FINAL_EP"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($puesto_ep_err)) ? 'has-error' : ''; ?>">
                            <label>Puesto entidad</label>
                            <input type="text" name="puesto_ep" class="form-control" value="<?php echo $puesto_ep; ?>">
                            <span class="help-block"><?php echo $puesto_ep_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($entidad_trabajada_ep)) ? 'has-error' : ''; ?>">
                            <label>Entidad trabajada</label>
                            <input type="text" name="entidad_trabajada_ep" class="form-control" value="<?php echo $entidad_trabajada_ep; ?>">
                            <span class="help-block"><?php echo $entidad_trabajada_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_inicial_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de inicio</label>
                            <input type="date" name="fecha_inicial_ep" class="form-control" value="<?php echo $fecha_inicial_ep; ?>">
                            <span class="help-block"><?php echo $fecha_inicial_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_final_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de finalizacion</label>
                            <input type="date" name="fecha_final_ep" class="form-control" value="<?php echo $fecha_final_ep; ?>">
                            <span class="help-block"><?php echo $fecha_final_err; ?></span>
                        </div>
                        <input type="hidden" name="id_experiencia_prof" value="<?php echo $id_experiencia_prof; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>