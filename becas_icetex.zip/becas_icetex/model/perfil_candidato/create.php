<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$nombre_cand = $apellido_cand = $pais_procedencia = $correo_electronico = $num_pasaporte = "";
$nombre_cand_err = $apellido_cand_err = $pais_procedencia_err = $correo_electronico_err = $num_pasaporte_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion nombre
    $input_nombre = trim($_POST["nombre_cand"]);
    if (empty($input_nombre)) {
        $nombre_cand_err = "Por favor ingresa un nombre.";
    } else {
        $nombre_cand = $input_nombre;
    }

    // Validacion apellido 
    $input_apellido = trim($_POST["apellido_cand"]);
    if (empty($input_apellido)) {
        $apellido_cand_err = "Por favor ingresa un apellido.";
    } else {
        $apellido_cand = $input_apellido;
    }

    // Validacion pais_procedencia
    $input_pais = trim($_POST["pais_procedencia"]);
    if (empty($input_pais)) {
        $pais_procedencia_err = "Por favor ingresa un pais.";
    } else {
        $pais_procedencia = $input_pais;
    }
    // Validacion correo_electronico
    $input_correo = trim($_POST["correo_electronico"]);
    if (empty($input_correo)) {
        $correo_electronico_err = "Por favor ingresa un correo_electronico";
    } else {
        $correo_electronico = $input_correo;
    }

    // Validacion num_pasaporte
    $input_pasaporte = trim($_POST["num_pasaporte"]);
    if (empty($input_pasaporte)) {
        $num_pasaporte_err = "Por favor ingresa un pasaporte valido";
    } else {
        $num_pasaporte = $input_pasaporte;
    }


    // Revisamos errores antes de continuar
    if (empty($nombre_cand_err) && empty($apellido_cand_err) && empty($pais_procedencia_err) && empty($correo_electronico_err) && empty($num_pasaporte_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO PERFIL_CANDIDATO (nombre_cand, apellido_cand, pais_procedencia, correo_electronico, num_pasaporte) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables para la sentencia
            $stmt->bindParam(1, $param_nombre, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_apellido, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_pais, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_correo, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_pasaporte, PDO::PARAM_STR);

            // settear variables
            $param_nombre = $nombre_cand;
            $param_apellido = $apellido_cand;
            $param_pais = $pais_procedencia;
            $param_correo = $correo_electronico;
            $param_pasaporte = $num_pasaporte;

            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar un perfil candidato a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nombre_cand_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre Candidato</label>
                            <input type="text" name="nombre_cand" class="form-control" value="<?php echo $nombre_cand; ?>">
                            <span class="help-block"><?php echo $nombre_cand_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($apellido_cand_err)) ? 'has-error' : ''; ?>">
                            <label>Apellido Candidato</label>
                            <input type="text" name="apellido_cand" class="form-control" value="<?php echo $apellido_cand; ?>">
                            <span class="help-block"><?php echo $apellido_cand_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pais_procedencia_err)) ? 'has-error' : ''; ?>">
                            <label>Pais de procedencia</label>
                            <input type="text" name="pais_procedencia" class="form-control" value="<?php echo $pais_procedencia; ?>">
                            <span class="help-block"><?php echo $pais_procedencia_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($correo_electronico_err)) ? 'has-error' : ''; ?>">
                            <label>Correo electronico</label>
                            <input type="email" name="correo_electronico" class="form-control" value="<?php echo $correo_electronico; ?>">
                            <span class="help-block"><?php echo $correo_electronico_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($num_pasaporte_err)) ? 'has-error' : ''; ?>">
                            <label>Numero de pasaporte</label>
                            <input type="text" name="num_pasaporte" class="form-control" value="<?php echo $num_pasaporte; ?>">
                            <span class="help-block"><?php echo $num_pasaporte_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>