<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$nombre_cand = $apellido_cand = $pais_procedencia = $correo_electronico = $num_pasaporte = "";
$nombre_cand_err = $apellido_cand_err = $pais_procedencia_err = $correo_electronico_err = $num_pasaporte_err = "";


// Processing form data when form is submitted
if (isset($_POST["id_perfil_candidato"]) && !empty($_POST["id_perfil_candidato"])) {
    // Get hidden input value
    $id_perfil_candidato = $_POST["id_perfil_candidato"];

    // Validate nombre
    $input_nombre = trim($_POST["nombre_cand"]);
    if (empty($input_nombre)) {
        $nombre_cand_err = "Por favor ingresa un nombre.";
    } else {
        $nombre_cand = $input_nombre;
    }
    // Validate apellido
    $input_apellido= trim($_POST["apellido_cand"]);
    if (empty($input_apellido)) {
        $apellido_cand_err = "Por favor ingresa un apellido.";
    } else {
        $apellido_cand = $input_apellido;
    }

    // Validate pais procedencia
    $input_pais = trim($_POST["pais_procedencia"]);
    if (empty($input_pais)) {
        $pais_procedencia_err = "Ingresa un pais valido";
    } else {
        $pais_procedencia = $input_pais;
    }

    // Validate correo electronico

    $input_correo = trim($_POST["correo_electronico"]);
    if (empty($input_correo)) {
        $correo_electronico_err = "Por favor ingresa un correo valido";
    }else {
        $correo_electronico = $input_correo;
    }

     //Validate num_pasaporte 
    $input_pasaporte = trim($_POST["num_pasaporte"]);
    if (empty($input_pasaporte)) {
        $num_pasaporte_err = "Porfavor ingresa un numero de pasaporte valido";
    }  else {
        $num_pasaporte = $input_pasaporte;
    }

    // Check input errors before inserting in database
    if (empty($nombre_cand_err) && empty($apellido_cand_err) && empty($pais_procedencia_err) && empty($correo_electronico_err) && empty($num_pasaporte_err)) {
        // Prepare an update statement
        $sql = "UPDATE PERFIL_CANDIDATO SET nombre_cand=?, apellido_cand=?, pais_procedencia=?, correo_electronico=?, num_pasaporte=? WHERE id_perfil_candidato=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_nombre, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_apellido, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_pais, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_correo, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_pasaporte, PDO::PARAM_STR);
            $stmt->bindParam(6, $param_id_perfil_candidato, PDO::PARAM_INT);

            // Set parameters
    
            $param_nombre = $nombre_cand;
            $param_apellido = $apellido_cand;
            $param_pais = $pais_procedencia;
            $param_correo = $correo_electronico;
            $param_pasaporte = $num_pasaporte;
            $param_id_perfil_candidato = $id_perfil_candidato;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_perfil_candidato"]) && !empty(trim($_GET["id_perfil_candidato"]))) {
        // Get URL parameter
        $id_perfil_candidato =  trim($_GET["id_perfil_candidato"]);

        // Prepare a select statement
        $sql = "SELECT * FROM PERFIL_CANDIDATO WHERE id_perfil_candidato = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id_perfil_candidato, PDO::PARAM_INT);

            // Set parameters
            $param_id_perfil_candidato = $id_perfil_candidato;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $nombre_cand = $row["NOMBRE_CAND"];
                    $apellido_cand = $row["APELLIDO_CAND"];
                    $pais_procedencia = $row["PAIS_PROCEDENCIA"];
                    $correo_electronico = $row["CORREO_ELECTRONICO"];
                    $num_pasaporte = $row["NUM_PASAPORTE"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nombre_cand_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre candidato</label>
                            <input type="text" name="nombre_cand" class="form-control" value="<?php echo $nombre_cand; ?>">
                            <span class="help-block"><?php echo $nombre_cand_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($apellido_cand_err)) ? 'has-error' : ''; ?>">
                            <label>Apellido candidato</label>
                            <input type="text" name="apellido_cand" class="form-control" value="<?php echo $apellido_cand; ?>">
                            <span class="help-block"><?php echo $apellido_cand_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($pais_procedencia_err)) ? 'has-error' : ''; ?>">
                            <label>Pais procedencia</label>
                            <input type="text" name="pais_procedencia" class="form-control" value="<?php echo $pais_procedencia; ?>">
                            <span class="help-block"><?php echo $pais_procedencia_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($correo_electronico_err)) ? 'has-error' : ''; ?>">
                            <label>Correo electronico</label>
                            <input type="email" name="correo_electronico" class="form-control" value="<?php echo $correo_electronico; ?>">
                            <span class="help-block"><?php echo $correo_electronico_err; ?></span>
                        </div>
                       
                        <div class="form-group <?php echo (!empty($num_pasaporte_err)) ? 'has-error' : ''; ?>">
                            <label>Numero pasaporte</label>
                            <input type="text" name="num_pasaporte" class="form-control" value="<?php echo $num_pasaporte; ?>">
                            <span class="help-block"><?php echo $num_pasaporte_err; ?></span>
                        </div>
                        <input type="hidden" name="id_perfil_candidato" value="<?php echo $id_perfil_candidato; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>