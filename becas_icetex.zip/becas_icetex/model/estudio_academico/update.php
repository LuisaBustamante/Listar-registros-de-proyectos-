<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$titulo_obtenido = $tipo_entidad = $fecha_finalizacion_ea = $fecha_inicio_ea = "";
$titulo_obtenido_err = $tipo_entidad_err = $fecha_finalizacion_err = $fecha_inicio_err ="";

// Processing form data when form is submitted
if (isset($_POST["id_estudio_academico"]) && !empty($_POST["id_estudio_academico"])) {
    // Get hidden input value
    $id_estudio_academico = $_POST["id_estudio_academico"];
    

    // Validate titulo_obtenido
    $input_titulo= trim($_POST["titulo_obtenido"]);
    if (empty($input_titulo)) {
        $titulo_obtenido_err = "Por favor ingresa un titulo academico valido.";
    } else {
        $titulo_obtenido = $input_titulo;
    }

    // Validate tipo entidad
    $input_tipo= trim($_POST["tipo_entidad"]);
    if (empty($input_tipo)) {
        $tipo_entidad_err= "Por favor ingresa un tipo de entidad academico valido.";
    } elseif (!filter_var($input_tipo, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => "/^[a-zA-Z\s]+$/")))) {
        $tipo_entidad_err= "Ingresa un nombre de tipo de entidad academico valido";
    } else {
        $tipo_entidad = $input_tipo;
    }

    // Validate fecha finalizacion 
    $input_fecha_finalizacion = trim($_POST["fecha_finalizacion_ea"]);
    if (empty($input_fecha_finalizacion)) {
        $fecha_finalizacion_err = "Ingresa una fecha valida";
    } else {
        $fecha_finalizacion_ea = $input_fecha_finalizacion;
    }

    // Validate fecha inicio
    $input_fecha_inicio = trim($_POST["fecha_inicio_ea"]);
    if (empty($input_fecha_inicio)) {
        $fecha_inicio_err = "Ingresa una fecha valida";
    } else {
        $fecha_inicio_ea = $input_fecha_inicio;
    }

    // Check input errors before inserting in database
    if (empty($titulo_obtenido_err) && empty($tipo_entidad_err) && empty($fecha_finalizacion_err) && empty($fecha_inicio_err)) {
        // Prepare an update statement
        $sql = "UPDATE ESTUDIO_ACADEMICO SET titulo_obtenido=?, tipo_entidad=?, fecha_finalizacion_ea=?, fecha_inicio_ea=? WHERE id_estudio_academico=?";

        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "sssi", $param_nombre, $param_direccion, $param_salario, $param_id);
            $stmt->bindParam(1, $param_titulo, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_tipo, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_finalizacion, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_fecha_inicio, PDO::PARAM_STR);
            $stmt->bindParam(5, $param_id, PDO::PARAM_INT);


            // Set parameters
            $param_titulo = $titulo_obtenido;
            $param_tipo = $tipo_entidad;
            $param_fecha_finalizacion = $fecha_finalizacion_ea;
            $param_fecha_inicio = $fecha_inicio_ea;
            $param_id = $id_estudio_academico;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close
    }

    // Close connection
    //mysqli_close($link);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET["id_estudio_academico"]) && !empty(trim($_GET["id_estudio_academico"]))) {
        // Get URL parameter
        $id_estudio_academico =  trim($_GET["id_estudio_academico"]);

        // Prepare a select statement
        $sql = "SELECT * FROM ESTUDIO_ACADEMICO WHERE id_estudio_academico = ?";
        //if($stmt = mysqli_prepare($link, $sql)){
        if ($stmt = $link->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            //mysqli_stmt_bind_param($stmt, "i", $param_id);
            $stmt->bindParam(1, $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id_estudio_academico;

            // Attempt to execute the prepared statement
            //if(mysqli_stmt_execute($stmt)){
            if ($stmt->execute()) {
                //$result = mysqli_stmt_get_result($stmt);
                $result = $stmt->fetchAll();

                //if(mysqli_num_rows($result) == 1){
                if (count($result) == 1) {
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    //$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $row = $result[0];

                    // Retrieve individual field value
                    $titulo_obtenido = $row["TITULO_OBTENIDO"];
                    $tipo_entidad = $row["TIPO_ENTIDAD"];
                    $fecha_finalizacion_ea = $row["FECHA_FINALIZACION_EA"];
                    $fecha_inicio_ea = $row["FECHA_INICIO_EA"];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        //mysqli_stmt_close($stmt);
        $stmt->closeCursor(); //PDO close

        // Close connection
        //mysqli_close($link);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Actualizar Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Actualizar Registro</h2>
                    </div>
                    <p>Edita los espacios y actualiza el registro.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($titulo_obtenido_err)) ? 'has-error' : ''; ?>">
                            <label>Titulo obtenido</label>
                            <input type="text" name="titulo_obtenido" class="form-control" value="<?php echo $titulo_obtenido; ?>">
                            <span class="help-block"><?php echo $titulo_obtenido_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($tipo_entidad_err)) ? 'has-error' : ''; ?>">
                            <label>Tipo entidad</label>
                            <input type="text" name="tipo_entidad" class="form-control" value="<?php echo $tipo_entidad; ?>">
                            <span class="help-block"><?php echo $tipo_entidad_err; ?></span>
                        </div>
                       
                        <div class="form-group <?php echo (!empty($fecha_finalizacion_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha finalizacion</label>
                            <input type="date" name="fecha_finalizacion_ea" class="form-control" value="<?php echo $fecha_finalizacion_ea; ?>">
                            <span class="help-block"><?php echo $fecha_finalizacion_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_inicio_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha inicio</label>
                            <input type="date" name="fecha_inicio_ea" class="form-control" value="<?php echo $fecha_inicio_ea; ?>">
                            <span class="help-block"><?php echo $fecha_inicio_err; ?></span>
                        </div>
                        <input type="hidden" name="id_estudio_academico" value="<?php echo $id_estudio_academico; ?>" />
                        <input type="submit" class="btn btn-primary" value="Actualizar">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>