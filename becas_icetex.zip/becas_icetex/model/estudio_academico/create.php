<?php
// Incluimos el archivo config.php
require_once "config.php";

// Definimos variables e inicializamos vacio
$titulo_obtenido= $tipo_entidad = $fecha_finalizacion_ea =$fecha_inicio_ea = "";
$titulo_obtenido_err = $tipo_entidad_err = $fecha_finalizacion_err = $fecha_inicio_err= "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validacion titulo academico
    $input_titulo = trim($_POST["titulo_obtenido"]);
    if (empty($input_titulo)) {
        $titulo_obtenido_err = "Por favor ingresa un titulo academico.";
    }  else {
        $titulo_obtenido = $input_titulo;
    }

    // Validacion tipo entidad
    $input_tipo = trim($_POST["tipo_entidad"]);
    if (empty($input_titulo)) {
        $tipo_entidad_err = "Por favor ingresa un tipo de entidad academico.";
    } else {
        $tipo_entidad = $input_tipo;
    }

    // Validacion fecha finalizacion
    $input_fecha_finalizacion = trim($_POST["fecha_finalizacion_ea"]);
    if (empty($input_fecha_finalizacion)) {
        $fecha_finalizacion_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_finalizacion_ea = $input_fecha_finalizacion;
    }

    // Validacion fecha inicio
    $input_fecha_inicio = trim($_POST["fecha_inicio_ea"]);
    if (empty($input_fecha_inicio)) {
        $fecha_inicio_err = "Por favor ingresa una fecha.";
    } else {
        $fecha_inicio_ea = $input_fecha_inicio;
    }

    // Revisamos errores antes de continuar
    if (empty($titulo_obtenido_err) && empty($tipo_entidad_err) && empty($fecha_finalizacion_err) && empty($fecha_inicio_err)) {
        // preparamos la sentancia INSERT
        $sql = "INSERT INTO ESTUDIO_ACADEMICO(titulo_obtenido, tipo_entidad, fecha_finalizacion_ea, fecha_inicio_ea) VALUES (?, ?, ?, ?)";

        if ($stmt = $link->prepare($sql)) {

            // Se hace el bindeo de variables paa la sentencia
            $stmt->bindParam(1, $param_titulo, PDO::PARAM_STR);
            $stmt->bindParam(2, $param_tipo, PDO::PARAM_STR);
            $stmt->bindParam(3, $param_fecha_final, PDO::PARAM_STR);
            $stmt->bindParam(4, $param_fecha_inicio, PDO::PARAM_STR);

            // settear variables
            $param_titulo = $titulo_obtenido;
            $param_tipo = $tipo_entidad;
            $param_fecha_final = $fecha_finalizacion_ea;
            $param_fecha_inicio = $fecha_inicio_ea;


            // Intentando ejecutar la declaración preparada
            if ($stmt->execute()) {
                // Registros creados con éxito. Redirigiendo a la página de destino
                header("location: index.php");
                exit();
            } else {
                echo "Paso algo, intente mas tarde...";
            }
        }

        // Cerrando sentencia
        $stmt->closeCursor(); //PDO close
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Crear Registro</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper {
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Registro</h2>
                    </div>
                    <p>Llena este formulario para agregar estudio academico a la base de datos</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($titulo_obtenido_err)) ? 'has-error' : ''; ?>">
                            <label>Titulo obtenido</label>
                            <input type="text" name="titulo_obtenido" class="form-control" value="<?php echo $titulo_obtenido; ?>">
                            <span class="help-block"><?php echo $titulo_obtenido_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($tipo_entidad_err)) ? 'has-error' : ''; ?>">
                            <label>Tipo de entidad</label>
                            <input type="text" name="tipo_entidad" class="form-control" value="<?php echo $tipo_entidad; ?>">
                            <span class="help-block"><?php echo $tipo_entidad_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_finalizacion_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de finalizacion</label>
                            <input type="date" name="fecha_finalizacion_ea" class="form-control" value="<?php echo $fecha_finalizacion_ea; ?>">
                            <span class="help-block"><?php echo $fecha_finalizacion_err; ?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_inicio_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha de inicio</label>
                            <input type="date" name="fecha_inicio_ea" class="form-control" value="<?php echo $fecha_inicio_ea; ?>">
                            <span class="help-block"><?php echo $fecha_inicio_err; ?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Crear">
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>